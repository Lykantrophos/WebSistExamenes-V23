// middleware/roles.js

function requireRole(rolesPermitidos = []) {
    return (req, res, next) => {

        // Middleware de autenticación debe haber colocado req.usuario
        if (!req.usuario) {
            return res.status(401).json({ msg: "No autenticado" });
        }

        // Validar que rolesPermitidos es un array
        if (!Array.isArray(rolesPermitidos)) {
            console.error("Error: rolesPermitidos no es un array:", rolesPermitidos);
            return res.status(500).json({ msg: "Error interno en permisos" });
        }

        // Comparar el rol del usuario
        if (!rolesPermitidos.includes(req.usuario.rol)) {
            return res.status(403).json({
                msg: "No tienes permisos para esta acción"
            });
        }

        next();
    };
}

module.exports = { requireRole };
