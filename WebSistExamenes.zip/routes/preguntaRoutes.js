// routes/preguntaRoutes.js

const express = require("express");
const router = express.Router();

const Pregunta = require("../models/Pregunta");
const auth = require("../middleware/auth");
const { requireRole } = require("../middleware/roles");

// ROLES PERMITIDOS PARA ADMINISTRAR PREGUNTAS
const ROLES_PROFES = ["ADMIN", "PROF_EDITOR", "PROFESOR"];

/* ================================
   GET /api/preguntas
================================ */
router.get("/", auth, requireRole(ROLES_PROFES), async (req, res) => {
  try {
    const preguntas = await Pregunta.find()
      .populate("subcategoria")
      .populate("rango_edad")
      .populate("nivel_dificultad")
      .populate("estado");

    res.json(preguntas);
  } catch (error) {
    console.error(error);
    res.status(500).json({ msg: "Error al obtener preguntas" });
  }
});

/* ================================
   GET /api/preguntas/:id
================================ */
router.get("/:id", auth, requireRole(ROLES_PROFES), async (req, res) => {
  try {
    const pregunta = await Pregunta.findById(req.params.id)
      .populate("subcategoria")
      .populate("rango_edad")
      .populate("nivel_dificultad")
      .populate("estado");

    if (!pregunta) {
      return res.status(404).json({ msg: "Pregunta no encontrada" });
    }

    res.json(pregunta);
  } catch (error) {
    console.error(error);
    res.status(500).json({ msg: "Error al obtener pregunta" });
  }
});

/* ================================
   POST /api/preguntas
================================ */
router.post("/", auth, requireRole(ROLES_PROFES), async (req, res) => {
  try {
    const {
      subcategoria,
      rango_edad,
      nivel_dificultad,
      estado,
      tipo_pregunta,
      titulo_pregunta,
      puntos_recomendados,
      tiempo_estimado,
      explicacion
    } = req.body;

    if (!subcategoria || !rango_edad || !nivel_dificultad || !estado || !tipo_pregunta || !titulo_pregunta) {
      return res.status(400).json({ msg: "Datos incompletos" });
    }

    const nueva = new Pregunta({
      subcategoria,
      rango_edad,
      nivel_dificultad,
      estado,
      tipo_pregunta,
      titulo_pregunta,
      puntos_recomendados,
      tiempo_estimado,
      explicacion
    });

    await nueva.save();

    res.json({
      msg: "Pregunta creada correctamente",
      pregunta: nueva
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ msg: "Error al crear pregunta" });
  }
});

/* ================================
   PUT /api/preguntas/:id
================================ */
router.put("/:id", auth, requireRole(ROLES_PROFES), async (req, res) => {
  try {
    const cambios = req.body;

    const editada = await Pregunta.findByIdAndUpdate(req.params.id, cambios, { new: true });

    if (!editada) {
      return res.status(404).json({ msg: "Pregunta no encontrada" });
    }

    res.json({
      msg: "Pregunta actualizada correctamente",
      pregunta: editada
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ msg: "Error al actualizar pregunta" });
  }
});

/* ================================
   DELETE /api/preguntas/:id
================================ */
router.delete("/:id", auth, requireRole(ROLES_PROFES), async (req, res) => {
  try {
    const eliminada = await Pregunta.findByIdAndDelete(req.params.id);

    if (!eliminada) {
      return res.status(404).json({ msg: "Pregunta no encontrada" });
    }

    res.json({ msg: "Pregunta eliminada correctamente" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ msg: "Error al eliminar pregunta" });
  }
});

module.exports = router;

